<!------------------Top Section---------------------------->
<section class="top-section" style="background-color:#60d0ac;height: auto;">
  <div class="container">
    <div class="row">
      <div class="col-12 m-auto">
        <p class="text-white mt-1 mb-1">(888)-1111-111 <span class="float-right">hello@talkmaze.com</span></p>
      </div>
    </div>
  </div>
</section>