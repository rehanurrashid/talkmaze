<h1><a name="_Toc39000012"></a><a name="_Toc12078635"><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">TERMS AND CONDITIONS</span></a><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="margin-top:12.0pt;margin-right:0in;margin-bottom:
12.0pt;margin-left:0in"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;
line-height:107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;
color:black">This Agreement was last revised on&nbsp;May 21<sup>st</sup>, 2020.<o:p></o:p></span></p><p class="MsoTocHeading"><span style="font-size:18.0pt;mso-bidi-font-size:16.0pt;
 line-height:107%;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
 mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin">Contents<o:p></o:p></span><span style="font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:107%;font-family:
 &quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-fareast-font-family:
 Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;
 mso-bidi-theme-font:minor-latin;color:windowtext"><w:sdtpr></w:sdtpr></span></p><p class="MsoToc1"><!--[if supportFields]><b
 style='mso-bidi-font-weight:normal'><span style='font-size:140.0pt;mso-bidi-font-size:
 12.0pt;line-height:107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'><span
 style='mso-element:field-begin'></span><span
 style='mso-spacerun:yes'> </span>TOC \o &quot;1-3&quot; \n \h \z \u <span
 style='mso-element:field-separator'></span></span></b><![endif]--><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000012"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-bidi-font-family:
 Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:yes">TERMS AND CONDITIONS</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:
 11.0pt;line-height:107%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-fareast-theme-font:
 minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000013"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">I.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:
 11.0pt;line-height:107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;
 mso-no-proof:yes">OUR INTRODUCTION</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;
 mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000014"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">II.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:
 11.0pt;line-height:107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;
 mso-no-proof:yes">DEFINITIONS</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;
 mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000015"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">III.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">INTERPRETATION</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-fareast-font-family:
 &quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000016"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">IV.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">COMMITMENT AND SCOPE</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-fareast-font-family:
 &quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000017"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">V.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp; &nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:
 11.0pt;line-height:107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;
 mso-no-proof:yes">OUR SERVICES</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;
 mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000018"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">VI.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">MODIFICATIONS TO THE SERVICE</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;
 mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000019"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">VII.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">ACCOUNT</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-fareast-font-family:
 &quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000020"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">VIII.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">USER SUBMISSION</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-fareast-font-family:
 &quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000021"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">IX.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">PAYMENT</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-fareast-font-family:
 &quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000024"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">X.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp; &nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:
 11.0pt;line-height:107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;
 mso-no-proof:yes">LIMITED GUARANTEE</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;
 mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000025"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">XI.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">GEOGRAPHIC RESTRICTION</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-fareast-font-family:
 &quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000026"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">XII.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">GENERAL CONDITIONS</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-fareast-font-family:
 &quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000027"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">XIII.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">YOUR COMMITMENT AND RESPONSIBILITIES</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;
 mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000028"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">XIV.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">EXCLUSION OF LIABILITY</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-fareast-font-family:
 &quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000029"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-fareast-font-family:Calibri;mso-hansi-font-family:Calibri;
 mso-bidi-font-family:Calibri;mso-no-proof:yes">XVI.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:
 11.0pt;line-height:107%;mso-ascii-font-family:Calibri;mso-fareast-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">NO RESPONSIBILITY</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-fareast-font-family:
 &quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000030"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-bidi-font-family:
 Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:yes">XVII.&nbsp; THIRD-PARTY LINKS</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:
 11.0pt;line-height:107%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-fareast-theme-font:
 minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000031"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">XVIII. </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-bidi-font-family:
 Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:yes">PERSONAL INFORMATION
 AND PRIVACY POLICY</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-fareast-font-family:
 &quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000032"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">XIX.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">ERRORS, INACCURACIES AND OMISSIONS</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;
 mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000033"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">XX.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">DISCLAIMER OF WARRANTIES; LIMITATION OF LIABILITY</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:
 11.0pt;line-height:107%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-fareast-theme-font:
 minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000034"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">XXI.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp;&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">COPYRIGHT AND TRADEMARK</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;
 mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000035"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">XXII.</span></b><b><span style="font-size: 14pt; line-height: 107%; color: windowtext;">&nbsp; </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
 107%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:
 yes">INDEMNIFICATION</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-fareast-font-family:
 &quot;Times New Roman&quot;;mso-fareast-theme-font:minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoToc1"><a href="file:///C:/Users/saham/Downloads/TalkMaze%20Terms%20and%20Conditions.docx#_Toc39000036"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-ascii-font-family:
 Calibri;mso-hansi-font-family:Calibri;mso-bidi-font-family:Calibri;mso-no-proof:
 yes">XXIII. </span></b><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-bidi-font-family:
 Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:yes">MISCELLANEOUS</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:
 11.0pt;line-height:107%;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-fareast-theme-font:
 minor-fareast;mso-no-proof:yes"><o:p></o:p></span></b></p><p class="MsoNormal"><!--[if supportFields]><b style='mso-bidi-font-weight:normal'><span
 style='font-size:140.0pt;mso-bidi-font-size:12.0pt;line-height:107%;
 mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'><span
 style='mso-element:field-end'></span></span></b><![endif]--><b><span style="font-size:16.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-bidi-font-family:
 Calibri;mso-bidi-theme-font:minor-latin;mso-no-proof:yes"><o:p>&nbsp;</o:p></span></b></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000013"><!--[if !supportLists]--><span style="font-size:18.0pt;
mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-fareast-font-family:
Calibri;color:#222222">I.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">OUR
INTRODUCTION</span></a><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="text-align:justify;mso-line-height-alt:11.75pt"><span class="gmail-heading2char"><b><span style="font-size:16.0pt;mso-bidi-font-size:
14.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:#2E74B5">www.talkmaze.com</span></b></span><span style="font-size:12.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black"> </span><span style="font-size:
14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;color:black">(“<u>we,</u>” “<u>us,</u>” or “<u>our</u>”) welcomes
you. &nbsp;</span><span style="font-size:12.0pt;mso-bidi-font-size:11.0pt;
mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoNormal" style="margin-bottom:11.25pt;text-align:justify;mso-line-height-alt:
13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">We offer you access to our
services through our “Website” (defined below) subject to the following Terms
of Service, which may be updated by us from time to time with or without notice
to you. &nbsp;By accessing and using this Website, you acknowledge that you
have read, understood and agree to be lawfully bound by these terms and
conditions and our Privacy Policy, which are hereby incorporated by reference
(collectively, this “Agreement”). In case you do not agree with any of these
terms, then please do not use the Website.&nbsp;</span><span style="font-size:
14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000014"></a><a name="_Toc12078637"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">II.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">DEFINITIONS</span></a><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoListParagraph" style="margin-left:31.5pt;mso-add-space:auto;
text-align:justify;text-indent:-20.25pt;mso-line-height-alt:11.25pt;mso-list:
l9 level1 lfo3"><!--[if !supportLists]--><span style="font-size:10.0pt;mso-bidi-font-size:
11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;mso-bidi-font-family:
Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">“<b>Agreement</b>”
denotes to this Terms and Conditions and the Privacy Policy and other documents
provided to you by the Website;&nbsp;</span><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoNormal" style="margin-left: 31.5pt; text-align: justify; text-indent: -20.25pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:10.0pt;mso-bidi-font-size:11.0pt;font-family:Symbol;
mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">“<b>Courses Package</b>” is a reference to our coaching
packages that we offer on our Website from time to time;<o:p></o:p></span></p><p class="MsoListParagraphCxSpFirst" style="margin-left:31.5pt;mso-add-space:
auto;text-align:justify;text-indent:-20.25pt;mso-line-height-alt:11.25pt;
mso-list:l9 level1 lfo3"><!--[if !supportLists]--><span style="font-size:10.0pt;
mso-bidi-font-size:14.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">“<b>Product</b>” or “<b>Item</b>”
refers to the product or goods available for sale on the website.</span><span style="font-size:14.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;
color:#222222"><o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-left:31.5pt;mso-add-space:
auto;text-align:justify;text-indent:-20.25pt;mso-line-height-alt:11.25pt;
mso-list:l9 level1 lfo3"><!--[if !supportLists]--><span style="font-size:10.0pt;
mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">“<b>Service</b>” or “<b>Services</b>” is a reference to any service defined below, which we may
supply and which you may request via our Website;</span><span style="font-size:
14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-left:31.5pt;mso-add-space:
auto;text-align:justify;text-indent:-20.25pt;mso-line-height-alt:11.25pt;
mso-list:l9 level1 lfo3"><!--[if !supportLists]--><span style="font-size:10.0pt;
mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">“<b>User</b>”,
“<b>You</b>” and “<b>your</b>” denotes the person who is accessing for taking
any service from us. User shall include the company, partnership, sole trader,
person, body corporate or association taking services of this Website;</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-left:31.5pt;mso-add-space:
auto;text-align:justify;text-indent:-20.25pt;mso-line-height-alt:11.25pt;
mso-list:l9 level1 lfo3"><!--[if !supportLists]--><span style="font-size:10.0pt;
mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:#222222">"<b>Members</b>" means users &nbsp;who have purchased a course Package available
on the website;<o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-left:31.5pt;mso-add-space:
auto;text-align:justify;text-indent:-20.25pt;mso-line-height-alt:11.25pt;
mso-list:l9 level1 lfo3"><!--[if !supportLists]--><span style="font-size:10.0pt;
mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">“<b>We</b>”,
“<b>us</b>”, “<b>our</b>” and “<b>Company</b>” are references to<b> Talk
Maze Inc</b>;</span><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoListParagraphCxSpLast" style="margin-left:31.5pt;mso-add-space:auto;
text-align:justify;text-indent:-20.25pt;mso-line-height-alt:11.25pt;mso-list:
l9 level1 lfo3"><!--[if !supportLists]--><span style="font-size:10.0pt;mso-bidi-font-size:
11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;mso-bidi-font-family:
Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">”<b>Website</b>”
shall mean and include&nbsp;</span><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:#555555">"</span><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222">http://www.talkmaze.com/</span></b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">, and any successor Website of the
Company or any of its affiliates;</span><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoNormal" style="margin-left: 31.5pt; text-align: justify; text-indent: -20.25pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:
10.0pt;mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:
Symbol;mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black;mso-themecolor:text1">“<b>User</b> <b>Account</b>” shall mean an electronic account opened by the user with
the Platform to avail services offered through the Website;<o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000015"></a><a name="_Toc12078638"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">III.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">INTERPRETATION</span></a><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoListParagraphCxSpFirst" style="margin-left:47.25pt;mso-add-space:
auto;text-align:justify;text-indent:-.25in;mso-line-height-alt:11.25pt;
mso-list:l11 level1 lfo1"><!--[if !supportLists]--><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:#222222">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">All
references to the singular include the plural and vice versa and the word
"includes" should be construed as "without limitation".</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-left:47.25pt;mso-add-space:
auto;text-align:justify;text-indent:-.25in;mso-line-height-alt:11.25pt;
mso-list:l11 level1 lfo1"><!--[if !supportLists]--><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:#222222">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">Words
importing any gender shall include all the other genders.</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-left:47.25pt;mso-add-space:
auto;text-align:justify;text-indent:-.25in;mso-line-height-alt:11.25pt;
mso-list:l11 level1 lfo1"><!--[if !supportLists]--><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:#222222">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">Reference
to any statute, ordinance or other law includes all regulations and other
instruments and all consolidations, amendments, re-enactments or replacements
for the time being in force.</span><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoListParagraphCxSpLast" style="margin-left:47.25pt;mso-add-space:
auto;text-align:justify;text-indent:-.25in;mso-line-height-alt:11.25pt;
mso-list:l11 level1 lfo1"><!--[if !supportLists]--><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:#222222">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">All
headings, bold typing, and italics (if any) have been inserted for convenience
of reference only and do not define limit or affect the meaning or
interpretation of the terms of this Agreement.</span><span style="font-size:
14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000016"></a><a name="_Toc12078639"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">IV.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">COMMITMENT
AND SCOPE</span></a><span style="font-size:26.0pt;
mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;
color:#222222"><o:p></o:p></span></h1><p class="gmail-msolistparagraph" style="margin-top:0in;margin-right:0in;
margin-bottom:0in;margin-left:47.25pt;margin-bottom:.0001pt;text-align:justify;
text-indent:-.25in;mso-line-height-alt:11.25pt;mso-list:l11 level1 lfo1"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;font-family:Symbol;
mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:#222222">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><b><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:black">Scope</span></b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">.&nbsp;These Terms govern your use of the Website and
the Services. Except as otherwise specified, these Terms do not apply to
Third-Party Products or Services, which are governed by their own terms of
service.</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p class="gmail-msolistparagraph" style="margin-top:0in;margin-right:0in;
margin-bottom:0in;margin-left:.5in;margin-bottom:.0001pt;text-align:justify;
text-indent:2.25pt;line-height:11.75pt"><span style="font-size:10.0pt;
mso-bidi-font-size:11.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;
color:#222222"><o:p>&nbsp;</o:p></span></p><p class="gmail-msolistparagraph" style="margin-top:0in;margin-right:0in;
margin-bottom:0in;margin-left:47.25pt;margin-bottom:.0001pt;text-align:justify;
text-indent:-.25in;mso-line-height-alt:11.75pt;mso-list:l11 level1 lfo1"><!--[if !supportLists]--><span style="font-size:14.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:#222222">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><b><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:black">Eligibility</span></b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">: </span><span style="font-size:14.0pt;font-family:
&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-theme-font:minor-latin;color:black">Our service is not
available to minors under the age of 16, if you are under the age of 16 then
please get acceptance from your parents/guardians prior to using our website
and services.</span><span style="font-size:14.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></p><p class="gmail-msolistparagraph" style="margin-top:0in;margin-right:0in;
margin-bottom:0in;margin-left:.5in;margin-bottom:.0001pt;text-indent:2.25pt;
line-height:11.75pt"><span style="font-size:11.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p>&nbsp;</o:p></span></p><p class="gmail-msolistparagraph" style="margin-top:0in;margin-right:0in;
margin-bottom:8.0pt;margin-left:47.25pt;text-align:justify;text-indent:-.25in;
mso-line-height-alt:11.75pt;mso-list:l11 level1 lfo1"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;font-family:Symbol;
mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:#222222">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><b><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:black">Electronic
Communication:</span></b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-theme-font:minor-latin;color:black">&nbsp;When you use
this Website or send e-mails and other electronic communications from your
desktop or mobile device to us, you are communicating with us electronically.
By sending, you agree to receive a reply communications from us electronically
in the same format and you can keep copies of these communications for your
records.</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000017"></a><a name="_Toc12078640"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">V.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">OUR
SERVICES</span></a><span style="font-size:26.0pt;
mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;
color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:11.25pt;
margin-left:.5in;text-align:justify;mso-line-height-alt:13.5pt"><a name="_Toc12078650"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;
mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">Here
at talkmaze.com, we offer a meticulously designed website to provide online professional
training for the users for all skill levels in the debate, public speaking and MUN
throughout the website.<o:p></o:p></span></a></p><p class="MsoNormal" style="margin: 0in 0in 7.5pt 0.5in; text-align: justify; line-height: normal; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">With
the use of innovative technologies, we provide online products and services to
the users </span><span style="font-size:14.0pt;color:black">which best suits their needs.</span><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000018"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">VI.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">MODIFICATIONS
TO THE SERVICE</span></a><span style="font-size:20.0pt;mso-bidi-font-size:18.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"> </span><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:11.25pt;
margin-left:.5in;text-align:justify;mso-line-height-alt:13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">We reserve the right, in our
discretion, to change, modify, add to, or remove portions of the Terms
(collectively, “<strong><span style="font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin">Changes</span></strong>”), at any time. We may notify you of changes
by sending an email to the address identified in your Account or by posting a
revised version of the Terms incorporating the Changes to our Website. </span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000019"><!--[if !supportLists]--><span style="font-size:18.0pt;
mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-fareast-font-family:
Calibri;color:#222222">VII.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">ACCOUNT</span></a><span style="font-size:26.0pt;
mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;
color:#222222"><o:p></o:p></span></h1><p class="gmail-msolistparagraph" style="margin-top:0in;margin-right:0in;
margin-bottom:0in;margin-left:.5in;margin-bottom:.0001pt;text-align:justify"><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">If you access this Website anonymously, you will not
be required to create a user name. But, to access certain Resources, you may be
required to provide specific information and to create a user ID and password
to establish an account.</span><span style="mso-bidi-font-size:11.0pt;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p class="gmail-msolistparagraph" style="margin-top:0in;margin-right:0in;
margin-bottom:8.0pt;margin-left:.5in;text-align:justify"><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">You accept that the details you provide about
establishing an account are correct and that you will keep your details
up-to-date. You are responsible for the security of all of your user names,
passwords, and registration information (such as unique account identifiers or
historical billing information), and you are solely responsible for any use
(authorized or not) of your accounts. You agree to notify us immediately about
any unauthorized activity regarding any of your accounts or other breaches of
security. We may at our discretion suspend or terminate any of your user names
and passwords at any time with or without notice.</span><span style="mso-bidi-font-size:
11.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000020"><!--[if !supportLists]--><span style="font-size:18.0pt;
mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-fareast-font-family:
Calibri">VIII.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin">USER SUBMISSION</span></a><span style="font-size:20.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin"><o:p></o:p></span></h1><p style="margin: 0in 0in 0.0001pt 0.5in; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; vertical-align: baseline;"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-fareast-font-family:Calibri;mso-fareast-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;
color:#333333">A.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><strong><span style="font-size:14.0pt;
mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;
color:#333333;border:none windowtext 1.0pt;mso-border-alt:none windowtext 0in;
padding:0in">Content Responsibility.</span></strong><span style="font-size:
14.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;
color:#333333">&nbsp;<o:p></o:p></span></p><p class="MsoNormal" style="margin-bottom: 0.0001pt; text-align: justify; line-height: normal; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border: none;"><span style="font-size:14.0pt;color:black">The website
permits you to post comments, feedback etc. (“content”) but you are solely
responsible for the content posted by you. You represent that you have required
permission to use the content.<o:p></o:p></span></p><p class="MsoNormal" style="margin-bottom: 7.5pt; text-align: justify; line-height: normal; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black;mso-themecolor:text1">Please do not
use content that:<o:p></o:p></span></p><ul type="disc">
 <li class="MsoNormal" style="color: black; text-align: justify; line-height: normal; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;mso-fareast-font-family:
     &quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin">contains
     ill-mannered, profane, abusive, racist or hateful language or expressions,
     text, photographs or illustrations that are pornographic or in poor taste,
     inflammatory attacks of a personal, racial or religious nature;<o:p></o:p></span></li>
 <li class="MsoNormal" style="color: black; text-align: justify; line-height: 115%; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;line-height:115%;
     mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;
     mso-bidi-theme-font:minor-latin">is defamatory, threatening, disparaging,
     grossly inflammatory, false, misleading, fraudulent, inaccurate, unfair,
     contains gross exaggeration or unsubstantiated claims;<o:p></o:p></span></li>
 <li class="MsoNormal" style="color: black; text-align: justify; line-height: 115%; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;line-height:115%;
     mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;
     mso-bidi-theme-font:minor-latin">violates the privacy rights of any third
     party, is unreasonably harmful or offensive to any individual or community;<o:p></o:p></span></li>
 <li class="MsoNormal" style="color: black; text-align: justify; line-height: 115%; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;line-height:115%;
     mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;
     mso-bidi-theme-font:minor-latin">discriminates on the grounds of race,
     religion, national origin, gender, age, marital status, sexual orientation
     or disability, or refers to such matters in any manner prohibited by law;<o:p></o:p></span></li>
 <li class="MsoNormal" style="color: black; text-align: justify; line-height: 115%; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;line-height:115%;
     mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;
     mso-bidi-theme-font:minor-latin">violates or inappropriately encourages the
     violation of any municipal, state, federal or international law, rule,
     regulation or ordinance;<o:p></o:p></span></li>
 <li class="MsoNormal" style="color: black; text-align: justify; line-height: 115%; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;line-height:115%;
     mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;
     mso-bidi-theme-font:minor-latin">uses or attempts to use another's
     account, password, service or system except as expressly permitted by the
     Terms of use uploads or transmits viruses or other harmful, disruptive or
     destructive files;<o:p></o:p></span></li>
 <li class="MsoNormal" style="color: black; text-align: justify; line-height: 115%; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;line-height:115%;
     mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;
     mso-bidi-theme-font:minor-latin">sends repeated messages related to
     another user and/or makes derogatory or offensive comments about another
     individual or repeats prior posting of the same message under multiple
     emails or subjects;<o:p></o:p></span></li>
</ul><p class="MsoListParagraph" style="margin: 14pt 0in 11.25pt 0.5in; text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border: none;"><span style="font-size:14.0pt;line-height:107%;color:black">Any submitted content
that includes, but is not limited to the following, will be refused. If
repeated violations occur, we reserve the right to cancel user access to&nbsp;the
website without advanced notice.<o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000021"></a><a name="_Toc35675112"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:22.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">IX.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:22.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222">PAYMENT</span></a><span style="font-size:
22.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoListParagraphCxSpFirst" style="margin-bottom: 11.25pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><b><span style="font-size:14.0pt;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;
color:black;mso-themecolor:text1">Online courses -</span></b><span style="font-size:14.0pt;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black;mso-themecolor:text1;
mso-bidi-font-weight:bold"> You can avail of our services by enrolling with our
website by submitting the enrolling form for a course package available on the
website. <o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-bottom: 11.25pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;
color:black;mso-themecolor:text1;mso-bidi-font-weight:bold">All the purchases
from this website shall be made under these terms and conditions. While
providing your details you must be careful and warrant that the details
provided are true and accurate. <o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-bottom: 11.25pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;
color:black;mso-themecolor:text1;mso-bidi-font-weight:bold">Payment mode shall
be: <o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-left: 1in; margin-bottom: 0.0001pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;
font-family:&quot;Courier New&quot;;mso-fareast-font-family:&quot;Courier New&quot;;color:black;
mso-themecolor:text1;mso-bidi-font-weight:bold">o<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp; </span></span><!--[endif]--><span style="font-size:14.0pt;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black;mso-themecolor:text1;
mso-bidi-font-weight:bold">PayPal <o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-bottom: 0.0001pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;
color:black;mso-themecolor:text1;mso-bidi-font-weight:bold">The Preferred
method of payment is PayPal. Credit cards are accepted via PayPal merchant
services. Accepted cards are: Visa / Delta / Electron / MasterCard / Eurocard /
Maestro/ American Express Debit cards are accepted if they have a Visa or
MasterCard logo.<o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-bottom: 11.25pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><a name="_Toc18825006"></a><a name="_Toc18674384"></a><a name="_Toc18621736"><!--[if !supportLists]--><span style="font-size:
14.0pt;mso-bidi-font-size:12.0pt;font-family:Symbol;mso-fareast-font-family:
Symbol;mso-bidi-font-family:Symbol;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
12.0pt;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold">Any purchase that you made with us is subject to acceptance by us. When
you make your purchase we will provide you an email to confirm that we have
received it. <o:p></o:p></span></a></p><p class="MsoListParagraphCxSpMiddle" style="margin-bottom: 11.25pt; margin-left: 33pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:
14.0pt;mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:
Symbol;mso-bidi-font-family:Symbol;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold">We may refuse or unable to process your order if:<o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-bottom: 11.25pt; margin-left: 88pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:
14.0pt;mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:
Symbol;mso-bidi-font-family:Symbol;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold">Your card or PayPal account does not give authorization for the payment
of the price.<o:p></o:p></span></p><p class="MsoListParagraphCxSpLast" style="margin-bottom: 11.25pt; margin-left: 88pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:
14.0pt;mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:
Symbol;mso-bidi-font-family:Symbol;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold">You do not meet the eligibility criteria set out above.<o:p></o:p></span></p><h1 style="margin-left:.5in;text-align:justify;text-indent:-.25in;mso-list:
l2 level1 lfo7"><a name="_Toc39000022"></a><a name="_Toc38197658"></a><a name="_Toc37430065"></a><a name="_Toc35675113"></a><a name="_Toc34512837"></a><a name="_Toc31099859"></a><a name="_Toc30886692"></a><a name="_Toc30022374"></a><a name="_Toc29949792"></a><a name="_Toc29285309"></a><a name="_Toc27678615"></a><a name="_Toc26995892"><!--[if !supportLists]--><span style="font-size: 14pt; font-family: Symbol; color: black;">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size: 14pt; font-family: Calibri, sans-serif; color: black;">You must
notify us instantly if any particulars are inappropriate. If your payment has
not been accepted you will be informed of this in writing along with the
reasons</span></a><span style="font-size: 14pt; font-family: Calibri, sans-serif; color: black;">.</span><span style="font-size: 14pt; font-family: Calibri, sans-serif; color: black;"><o:p></o:p></span></h1><h1 style="margin-left:.5in;text-align:justify;text-indent:-.25in;mso-list:
l2 level1 lfo7"><a name="_Toc39000023"><!--[if !supportLists]--><span style="font-size: 14pt; font-family: Symbol; color: black;">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size: 14pt; font-family: Calibri, sans-serif; color: black;">The refund
shall be applicable as per our Refund policy.</span></a><span style="font-size: 14pt; font-family: Calibri, sans-serif; color: black;"><o:p></o:p></span></h1><p class="MsoListParagraphCxSpFirst" style="margin-bottom: 0.0001pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:black;mso-themecolor:text1">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black;mso-themecolor:text1">We
are happy to support you if there is any issue you can contact our back-office
team for any inquiry or problem.<o:p></o:p></span></p><p class="MsoListParagraphCxSpLast" style="margin-left: 33pt; margin-bottom: 0.0001pt; text-align: justify; text-indent: -11pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp; </span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">We take user feedback very
seriously and use it to constantly improve our products and quality of service.<o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000024"><!--[if !supportLists]--><span style="font-size:18.0pt;
mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-fareast-font-family:
Calibri;color:#222222">X.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">LIMITED
GUARANTEE</span></a><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="text-align:justify;text-indent:.5in;mso-line-height-alt:
13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">By availing our services:</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoListParagraphCxSpFirst" style="margin-left:47.25pt;mso-add-space:
auto;text-align:justify;text-indent:-.25in;mso-line-height-alt:11.25pt;
mso-list:l11 level1 lfo1"><!--[if !supportLists]--><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:#222222">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">We
provide an opportunity for you to avail the offered Services from our Website;</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoListParagraphCxSpLast" style="margin-left:47.25pt;mso-add-space:
auto;text-align:justify;text-indent:-.25in;mso-line-height-alt:11.25pt;
mso-list:l11 level1 lfo1"><!--[if !supportLists]--><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;
mso-bidi-font-family:Symbol;color:#222222">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">We
do not provide any warranty or guarantee that the Courses and/or Service
descriptions are accurate, complete, reliable, current, or error-free. If a
Service offered by the Website is not as described, your sole remedy is to inform
us about the Services to allow us to take further action.</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000025"><!--[if !supportLists]--><span style="font-size:18.0pt;
mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-fareast-font-family:
Calibri;color:#222222">XI.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">GEOGRAPHIC
RESTRICTION</span></a><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="margin-bottom:11.25pt;text-align:justify;mso-line-height-alt:
13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">We reserve the right, but
not the obligation, to limit the usage or supply of any service or course to
any person, geographic region or jurisdiction. We may use this right as per the
necessity. We reserve the right to suspend any Service at any time. Any offer
to provide any Service made on our Website is invalid where banned.</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc12078646"></a><a name="_Toc39000026"></a><a name="_Toc35675114"></a><a name="_Toc30540084"></a><a name="_Toc29855587"><!--[if !supportLists]--><span style="font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-fareast-font-family:Calibri;
color:#222222">XII.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">GENERAL
CONDITIONS</span></a><span style="font-size:20.0pt;mso-bidi-font-size:18.0pt;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoListParagraphCxSpFirst" style="margin-bottom: 11.25pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;font-family:
Symbol;mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:black;
mso-themecolor:text1;mso-bidi-font-weight:bold">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">We
do not guarantee the accuracy, completeness, validity, or timeliness of
information listed by us.</span><span style="font-size:14.0pt;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black;mso-themecolor:text1;
mso-bidi-font-weight:bold"><o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-bottom: 11.25pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;mso-bidi-font-family:
Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">We
make material changes to these terms and conditions from time to time, we may
notify you either by prominently posting a notice of such changes or via email
communication.<o:p></o:p></span></p><p class="MsoListParagraphCxSpLast" style="margin-bottom: 0.0001pt; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;font-family:Symbol;mso-fareast-font-family:Symbol;mso-bidi-font-family:
Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">The
website is licensed to you on a limited, non-exclusive, non-transferrable, non-sub-licensable
basis, solely to be used in connection with the Service for your private,
personal, non-commercial use, subject to all the terms and conditions of this
Agreement as they apply to the Service.<o:p></o:p></span></p><p style="margin: 0in 0in 0.0001pt 0.5in; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; vertical-align: baseline;"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;font-family:Symbol;
mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-fareast-font-family:Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-theme-font:minor-latin;color:black">We reserve the right
for any printing errors on this site as well as the final sales of
products.&nbsp;We do not guarantee that the images reflect the exact appearance
of the products as a certain color difference may occur depending on the
monitor, photo quality, and resolution.&nbsp;We always try our best to expose
the products as accurately as possible.<o:p></o:p></span></p><p class="MsoListParagraph" style="margin-bottom: 0.0001pt; text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;color:black"><o:p>&nbsp;</o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000027"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">XIII.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:18.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222">YOUR COMMITMENT AND RESPONS</span></a><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">IBILITIES</span><span style="font-size:26.0pt;
mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;
color:#222222"><o:p></o:p></span></h1><p class="MsoListParagraphCxSpFirst" style="margin-bottom:0in;margin-bottom:.0001pt;
mso-add-space:auto;text-align:justify;text-indent:-.25in;mso-line-height-alt:
11.25pt;mso-list:l1 level1 lfo4"><!--[if !supportLists]--><span style="font-size:
14.0pt;mso-bidi-font-size:12.0pt;font-family:Symbol;mso-fareast-font-family:
Symbol;mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
12.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">You
shall use the website Service for a lawful purpose and comply with all the
applicable laws;<o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="text-align:justify;text-indent:-.25in;
mso-line-height-alt:11.25pt;mso-list:l1 level1 lfo4"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:Symbol;
mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
12.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">You
shall not upload, any content that:<o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="margin-left:1.0in;mso-add-space:
auto;text-align:justify;text-indent:-.25in;mso-line-height-alt:11.25pt;
mso-list:l1 level2 lfo4"><!--[if !supportLists]--><span style="font-size:14.0pt;
mso-bidi-font-size:12.0pt;font-family:&quot;Courier New&quot;;mso-fareast-font-family:
&quot;Courier New&quot;;color:black">o<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp; </span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">Defamatory, infringes any trademark,
copyright, or any proprietary rights of any person or affect any one’s privacy,
contain violence or hate speech, including any sensitive information about any
person.<o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="text-align:justify;text-indent:-.25in;
mso-line-height-alt:11.25pt;mso-list:l1 level1 lfo4"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:Symbol;
mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
12.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">You
shall not use or access the Website for collecting any market research for some
competing business;<o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="text-align:justify;text-indent:-.25in;
mso-line-height-alt:11.25pt;mso-list:l1 level1 lfo4"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:Symbol;
mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
12.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">You
shall not use any virus, hacking tool for interfering in the operation of the
Website or data and files of the Website;<o:p></o:p></span></p><p class="MsoListParagraphCxSpMiddle" style="text-align:justify;text-indent:-.25in;
mso-line-height-alt:11.25pt;mso-list:l1 level1 lfo4"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:Symbol;
mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
12.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">You
will not use any device, scraper or any automated thing to access our Website for
any means without taking permission.<o:p></o:p></span></p><p class="MsoListParagraphCxSpLast" style="text-align:justify;text-indent:-.25in;
mso-line-height-alt:11.25pt;mso-list:l1 level1 lfo4"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:Symbol;
mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:black">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
12.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">You
will inform us about anything is inappropriate or&nbsp; you can inform us if
you find something illegal;<o:p></o:p></span></p><p class="MsoNormal" style="margin-left: 0.5in; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:Symbol;
mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:black;
mso-themecolor:text1;mso-bidi-font-weight:bold">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
12.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black;
mso-themecolor:text1;mso-bidi-font-weight:bold">You will not interfere with or
try to interrupt the proper operation of the Website through the use of any
virus, device, information collection or transmission mechanism, software or
routine, or access or try to gain access to any data, files, or passwords
connected to the Website through hacking, password or data mining, or any other
means;<o:p></o:p></span></p><p class="MsoNormal" style="margin-left: 0.5in; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:Symbol;
mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:black;
mso-themecolor:text1;mso-bidi-font-weight:bold">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
12.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black;
mso-themecolor:text1;mso-bidi-font-weight:bold">You will not take any action
that levies or may levy (in our sole decision) an unreasonable or unreasonably
big load on our technical arrangement; and<o:p></o:p></span></p><p class="MsoNormal" style="margin-left: 0.5in; text-align: justify; text-indent: -0.25in; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><!--[if !supportLists]--><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:Symbol;
mso-fareast-font-family:Symbol;mso-bidi-font-family:Symbol;color:black;
mso-themecolor:text1;mso-bidi-font-weight:bold">·<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:14.0pt;mso-bidi-font-size:
12.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black;
mso-themecolor:text1;mso-bidi-font-weight:bold">You will let us know about the unsuitable
content of which you become aware. &nbsp;If you discover something that
infringes any law, please let us know, and we’ll review it.<o:p></o:p></span></p><p class="MsoNormal" style="text-align:justify;mso-line-height-alt:11.25pt"><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">We reserve the right, in our sole
and absolute discretion, to deny you access to the Website or any service, or
any portion of the Website or service, without notice, and to remove any
content.</span><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;
mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l4 level1 lfo2"><a name="_Toc39000028"></a><a name="_Toc12078648"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">XIV.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:18.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222">EXCLUSION OF LIABILITY</span></a><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="margin-bottom: 11.25pt; text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">You understand and agree that we
(A)does not guarantee the accuracy, completeness, validity, or timeliness of
information listed by us or any third parties; and (B) shall not be responsible
for any materials posted by us or any third party. You shall use your own
judgment, caution, and common sense in evaluating any prospective methods or
offers and any information provided by us or any third party.</span><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoNormal" style="margin-bottom:11.25pt;text-align:justify;mso-line-height-alt:
13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:
Calibri;color:black">Further, we shall not be liable for direct, indirect
consequential or any other form of loss or damage that may be suffered by a user
through the use of the www.qubipersonalchef.com Website including loss of data
or information or any kind of financial or physical loss or damage<o:p></o:p></span></p><p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;mso-line-height-alt:13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:
12.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">In
no event shall <b>http://talkmaze.com/</b>,
nor its owners, directors, employees, partners, agents, suppliers, or
affiliates, be accountable for any indirect, incidental, special, eventful or
exemplary costs, including without limitation, loss of proceeds, figures,
usage, goodwill, or other intangible losses, consequential from (i) your use or
access of or failure to access or use the Service; (ii) any conduct or content
of any third party on the Service; (iii) any content attained from the Service;
and (iv) unlawful access, use or alteration of your transmissions or content,
whether or not based on guarantee, agreement, domestic wrong (including
carelessness) or any other lawful concept, whether or not we've been aware of
the possibility of such damage, and even if a cure set forth herein is
originate to have futile of its important purpose.<o:p></o:p></span></p><p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;mso-line-height-alt:13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:
12.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:#222222"><o:p>&nbsp;</o:p></span></p><h1 style="margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:
82.5pt;text-indent:-.5in;mso-list:l3 level1 lfo10"><a name="_Toc12078651"></a><a name="_Toc39000029"></a><a name="_Toc32620813"><!--[if !supportLists]--><span style="font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-fareast-font-family:Calibri;
color:#222222">XVI.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:22.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">NO RESPONSIBILITY</span></a><span style="color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="margin-top:14.0pt;margin-right:0in;margin-bottom:
.25in;margin-left:0in;text-align:justify;line-height:normal"><span style="font-size:14.0pt;color:black">We
are not responsible to you for: </span><span style="font-size:15.0pt;color:black"><o:p></o:p></span></p><p class="MsoNormal" style="margin-top:14.0pt;margin-right:0in;margin-bottom:
0in;margin-left:.5in;margin-bottom:.0001pt;text-align:justify;text-indent:-.25in;
line-height:normal;mso-list:l7 level1 lfo9;border:none;mso-padding-alt:31.0pt 31.0pt 31.0pt 31.0pt;
mso-border-shadow:yes"><!--[if !supportLists]--><span style="font-size:15.0pt;font-family:&quot;Noto Sans Symbols&quot;;mso-fareast-font-family:
&quot;Noto Sans Symbols&quot;;mso-bidi-font-family:&quot;Noto Sans Symbols&quot;;color:black">●<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:15.0pt;color:black">any
reliance that you may place on any material or commentary posted on our
website. Please note that nothing contained in our website or the material
published on it is intended to amount to advice on which you should rely; or<o:p></o:p></span></p><p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:0in;
margin-left:.5in;margin-bottom:.0001pt;text-align:justify;text-indent:-.25in;
line-height:normal;mso-list:l7 level1 lfo9;border:none;mso-padding-alt:31.0pt 31.0pt 31.0pt 31.0pt;
mso-border-shadow:yes"><!--[if !supportLists]--><span style="font-size:15.0pt;font-family:&quot;Noto Sans Symbols&quot;;mso-fareast-font-family:
&quot;Noto Sans Symbols&quot;;mso-bidi-font-family:&quot;Noto Sans Symbols&quot;;color:black">●<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:15.0pt;color:black">any
losses you suffer because the information you put into our website is
inaccurate or incomplete; or<o:p></o:p></span></p><p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:0in;
margin-left:.5in;margin-bottom:.0001pt;text-align:justify;text-indent:-.25in;
line-height:normal;mso-list:l7 level1 lfo9;border:none;mso-padding-alt:31.0pt 31.0pt 31.0pt 31.0pt;
mso-border-shadow:yes"><!--[if !supportLists]--><span style="font-size:15.0pt;font-family:&quot;Noto Sans Symbols&quot;;mso-fareast-font-family:
&quot;Noto Sans Symbols&quot;;mso-bidi-font-family:&quot;Noto Sans Symbols&quot;;color:black">●<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:15.0pt;color:black">any
losses you suffer because you cannot use our website at any time; or<o:p></o:p></span></p><p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:0in;
margin-left:.5in;margin-bottom:.0001pt;text-align:justify;text-indent:-.25in;
line-height:normal;mso-list:l7 level1 lfo9;border:none;mso-padding-alt:31.0pt 31.0pt 31.0pt 31.0pt;
mso-border-shadow:yes"><!--[if !supportLists]--><span style="font-size:15.0pt;font-family:&quot;Noto Sans Symbols&quot;;mso-fareast-font-family:
&quot;Noto Sans Symbols&quot;;mso-bidi-font-family:&quot;Noto Sans Symbols&quot;;color:black">●<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:15.0pt;color:black">any
errors in or omissions from our website; or<o:p></o:p></span></p><p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:0in;
margin-left:.5in;margin-bottom:.0001pt;text-align:justify;text-indent:-.25in;
line-height:normal;mso-list:l7 level1 lfo9;border:none;mso-padding-alt:31.0pt 31.0pt 31.0pt 31.0pt;
mso-border-shadow:yes"><!--[if !supportLists]--><span style="font-size:15.0pt;font-family:&quot;Noto Sans Symbols&quot;;mso-fareast-font-family:
&quot;Noto Sans Symbols&quot;;mso-bidi-font-family:&quot;Noto Sans Symbols&quot;;color:black">●<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:15.0pt;color:black">any
losses you may suffer by relying on any commentary, postings or reviews (of our
services or that of our partners) on our website; or<o:p></o:p></span></p><p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:0in;
margin-left:.5in;margin-bottom:.0001pt;text-align:justify;text-indent:-.25in;
line-height:normal;mso-list:l7 level1 lfo9;border:none;mso-padding-alt:31.0pt 31.0pt 31.0pt 31.0pt;
mso-border-shadow:yes"><!--[if !supportLists]--><span style="font-size:15.0pt;font-family:&quot;Noto Sans Symbols&quot;;mso-fareast-font-family:
&quot;Noto Sans Symbols&quot;;mso-bidi-font-family:&quot;Noto Sans Symbols&quot;;color:black">●<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:15.0pt;color:black">any
unauthorized access or loss of personal information that is beyond our control.<o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l8 level1 lfo11"><a name="_Toc39000030"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">XVII.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;"> </span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:18.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222">THIRD-PARTY LINKS</span></a><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="margin-bottom:11.25pt;text-align:justify;mso-line-height-alt:
13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">We may comprise links to
external or third-party Websites (“<u>External Sites</u>”). &nbsp;These links
are provided exclusively as ease to you and not as an authorization by us of
the content on such External Sites. &nbsp;The content of such External Sites is
created and used by others. &nbsp;You can communicate the site administrator
for those External Sites. &nbsp;We are not accountable for the content provided
in the link of any External Sites and do not provide any representations about
the content or correctness of the information on such External Sites. &nbsp;You
should take safety measures when you are downloading files from all these
Websites to safeguards your computer from viruses and other critical programs.
&nbsp;If you agree to access linked External Sites, you do so at your own risk.</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l8 level1 lfo11"><a name="_Toc39000031"></a><a name="_Toc12078653"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">XVIII.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">PERSONAL
INFORMATION AND PRIVACY POLICY</span></a><span style="font-size:26.0pt;
mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;
color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="margin-bottom:11.25pt;text-align:justify;mso-line-height-alt:
13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">By accessing or using the Website,
you approve us to use, store, or otherwise process your personal information as
per our Privacy Policy.</span><span style="font-size:14.0pt;mso-bidi-font-size:
11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l8 level1 lfo11"><a name="_Toc39000032"></a><a name="_Toc12078654"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">XIX.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:18.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222">ERRORS, INACCURACIES, AND OMISSIONS</span></a><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="margin-bottom:11.25pt;text-align:justify;mso-line-height-alt:
13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">Every effort has been
taken to ensure that the information offered on our Website is accurate and
error-free. We apologize for any errors or omissions that may have occurred. We
cannot give you any warranty that usage of the Website will be error-free or
fit for purpose, timely, that defects will be amended, or that the site or the
server that makes it available are free of viruses or bugs or signifies the
full functionality, accuracy, reliability of the Website and no warranty shall
be provided by us for its suitability for any purpose.</span><span style="font-size:12.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l8 level1 lfo11"><a name="_Toc39000033"></a><a name="_Toc12078655"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">XX.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">DISCLAIMER
OF WARRANTIES; LIMITATION OF LIABILITY</span></a><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><p style="margin:0in;margin-bottom:.0001pt;text-align:justify"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">OUR WEBSITE AND THE SERVICE ARE PROVIDED ON AN “AS IS”
AND “AS AVAILABLE” BASIS WITHOUT ANY WARRANTIES OF ANY KIND, INCLUDING THAT THE
WEBSITE WILL OPERATE ERROR-FREE OR THAT THE WEBSITE, ITS SERVERS OR ITS CONTENT
OR SERVICE ARE FREE OF COMPUTER VIRUSES OR SIMILAR CONTAMINATION OR DESTRUCTIVE
FEATURES.</span><span style="font-size:16.0pt;mso-bidi-font-size:12.0pt;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p style="margin-top:0in;margin-right:0in;margin-bottom:12.0pt;margin-left:
0in;text-align:justify"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-theme-font:minor-latin;color:black">&nbsp;</span><span style="font-size:16.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></p><p style="margin:0in;margin-bottom:.0001pt;text-align:justify"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">WE DISCLAIM ALL LICENSES OR WARRANTIES, INCLUDING, BUT
NOT LIMITED TO, LICENSES OR WARRANTIES OF TITLE, MERCHANTABILITY, NON-VIOLATION
OF THIRD PARTIES’ RIGHTS, AND FITNESS FOR PARTICULAR PURPOSE AND ANY WARRANTIES
ARISING FROM A MATTER OF DEALING, COURSE OF PERFORMANCE, OR USAGE OF TRADE. IN
RELATION WITH ANY WARRANTY, CONTRACT, OR COMMON LAW TORT CLAIMS: (I) WE SHALL
NOT BE LIABLE FOR ANY UNINTENDED, INCIDENTAL, OR SUBSTANTIAL DAMAGES, LOST
PROFITS, OR DAMAGES RESULTING FROM LOST DATA OR BUSINESS STOPPAGE
&nbsp;RESULTING FROM THE USE OR INABILITY TO ACCESS AND USE THE WEBSITE OR THE
CONTENT, EVEN IF WE HAVE BEEN RECOMMENDED OF THE POSSIBILITY OF SUCH DAMAGES.</span><span style="font-size:16.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></p><p style="margin:0in;margin-bottom:.0001pt;text-align:justify"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">THE WEBSITE MAY COMPRISE TECHNICAL INCORRECTNESS OR
TYPOGRAPHICAL ERRORS OR OMISSIONS. UNLESS REQUIRED BY APPLICABLE LAWS, WE ARE
NOT ACCOUNTABLE FOR ANY SUCH TYPOGRAPHICAL, TECHNICAL, OR PRICING ERRORS
RECORDED ON THE WEBSITE. &nbsp;THE WEBSITE MAY CONTAIN INFORMATION ON CERTAIN
SERVICES, NOT ALL OF WHICH ARE AVAILABLE IN EVERY LOCATION. &nbsp;A REFERENCE
TO A SERVICE ON THE WEBSITES DOES NOT SUGGEST THAT SUCH SERVICE IS OR WILL BE
ACCESSIBLE IN YOUR LOCATION. &nbsp;WE RESERVE THE RIGHT TO DO CHANGES, CORRECTIONS,
AND/OR IMPROVEMENTS TO THE WEBSITE AT ANY TIME WITHOUT NOTICE.<o:p></o:p></span></p><p style="margin:0in;margin-bottom:.0001pt;text-align:justify"><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p>&nbsp;</o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l8 level1 lfo11"><a name="_Toc12078656"><!--[if !supportLists]--><span style="font-size:18.0pt;
mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-fareast-font-family:
Calibri;color:#222222">XXI.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp; </span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:18.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222">&nbsp;</span></a><a name="_Toc39000034"><span style="font-size:20.0pt;mso-bidi-font-size:18.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222">COPYRIGHT AND TRADEMARK</span></a><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="text-align:justify"><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;line-height:107%;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">We have provided certain materials
such as graphics, logo, photo, designs audio recording, text, software etc.
(collectively referred to as “Content”). The Content may be possessed by us or
third parties. &nbsp;&nbsp;Unauthorized use of the Content may infringe
copyright, trademark, and other laws. &nbsp;You have no rights in or to the
Content, and you will not take the Content except as allowed under this
Agreement. &nbsp;No other use is allowed without prior written consent from us.
&nbsp;You must recollect all copyright and other proprietary notices contained
in the original Content on any copy you make of the Content. &nbsp;You shall
not modify or transfer any copyrighted content in any way for any public or
commercial purpose. <o:p></o:p></span></p><p class="MsoNormal" style="text-align:justify"><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;line-height:107%;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">If you violate any provision of
this Agreement, your rights to access or use the website shall be terminated
and you must with immediate effect destroy the copies you have created from the
content.<o:p></o:p></span></p><p class="MsoNormal" style="text-align:justify"><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;line-height:107%;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">Our trademarks, service marks, and
logos used and displayed on the Website are registered and unregistered
trademarks or service marks of us. &nbsp;Other company, product, and service
names located on the Website may be trademarks or service marks owned by others
(the “Third-Party Trademarks,” and, collectively with us, the “Trademarks”).
&nbsp;Nothing on the Website should be construed as granting, by implication,
estoppel, or otherwise, any license or right to use the Trademarks, without our
prior written permission specific for each such use. &nbsp; </span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l8 level1 lfo11"><a name="_Toc39000035"></a><a name="_Toc12078657"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">XXII.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;"> </span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:18.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222">INDEMNIFICATIO</span></a><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">N</span><span style="font-size:26.0pt;
mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;
color:#222222"><o:p></o:p></span></h1><p class="MsoNormal" style="margin-bottom:11.25pt;text-align:justify;mso-line-height-alt:
13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">You agree to secure,
indemnify, and hold us and our officers, directors, employees, successors, licensees,
and allocates harmless from and against any dues, actions, or demands,
including, without restriction, judicious legal and accounting fees, arising or
consequential from your breach of this Agreement or your misappropriation of
the Content or the Website. &nbsp;We shall provide you notice of such claim,
suit, or proceeding at your expense. &nbsp;We reserve the right, at your
expense, to undertake the exclusive defense and control of any case that is
subject to indemnification under this section. &nbsp;In such case, you agree to
cooperate with any reasonable requests assisting our defense of such matter.</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h1 style="margin-left:82.5pt;text-indent:-.5in;mso-list:l8 level1 lfo11"><a name="_Toc39000036"></a><a name="_Toc12078658"><!--[if !supportLists]--><span style="font-size:18.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-fareast-font-family:Calibri;color:#222222">XXIII.<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><!--[endif]--><span style="font-size:20.0pt;mso-bidi-font-size:
18.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:#222222">MISCELLANEOUS</span></a><span style="font-size:26.0pt;mso-bidi-font-size:24.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></h1><h3><a name="_Toc39000037"></a><a name="_Toc38197673"></a><a name="_Toc37430079"></a><a name="_Toc35446799"></a><a name="_Toc32691003"></a><a name="_Toc29655183"></a><a name="_Toc29654651"></a><a name="_Toc28270233"></a><a name="_Toc26650210"></a><a name="_Toc25043003"></a><a name="_Toc24776210"></a><a name="_Toc22984345"></a><a name="_Toc21183322"></a><a name="_Toc21164896"></a><a name="_Toc19817776"></a><a name="_Toc18962817"></a><a name="_Toc18825018"></a><a name="_Toc18674398"></a><a name="_Toc18621749"></a><a name="_Toc18570254"></a><a name="_Toc12078659"><b><span style="font-size:16.0pt;mso-bidi-font-size:14.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">SEVERABILITY</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#1F4D78"><o:p></o:p></span></b></h3><p class="MsoNormal" style="margin-bottom:11.25pt;text-align:justify;mso-line-height-alt:
13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">If any provision of these
Terms is found to be unenforceable or inacceptable, that provision will be
limited or eliminated to the minimum extent necessary so that the Terms will
otherwise remain in full force and effect and enforceable.</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h3><a name="_Toc39000038"></a><a name="_Toc38197674"></a><a name="_Toc37430080"></a><a name="_Toc35446800"></a><a name="_Toc32691004"></a><a name="_Toc29655184"></a><a name="_Toc29654652"></a><a name="_Toc28270234"></a><a name="_Toc26650211"></a><a name="_Toc25043004"></a><a name="_Toc24776211"></a><a name="_Toc22984346"></a><a name="_Toc21183323"></a><a name="_Toc21164897"></a><a name="_Toc19817777"></a><a name="_Toc18962818"></a><a name="_Toc18825019"></a><a name="_Toc18674399"></a><a name="_Toc18621750"></a><a name="_Toc18570255"></a><a name="_Toc12078660"><b><span style="font-size:16.0pt;mso-bidi-font-size:14.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">TERMINATION</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#1F4D78"><o:p></o:p></span></b></h3><p class="MsoNormal" style="text-align:justify"><b><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;line-height:107%;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">Term</span></b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">.&nbsp;The Services will
be provided to you can be canceled or terminated by us. We may terminate these
Services at any time, with or without cause, upon written notice. We will have
no liability to you or any third party because of such termination. Termination
of these Terms will terminate all of your Services subscriptions.</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:107%;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><p class="MsoNormal" style="margin-bottom:11.25pt;text-align:justify;mso-line-height-alt:
13.5pt"><b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">Effect of Termination</span></b><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">.&nbsp;Upon termination of these
Terms for any reason, or cancellation or expiration of your Services:&nbsp;(a)
We will cease providing the Services;&nbsp;(b)&nbsp;you will not be entitled to
any refunds or usage fees, or any other fees, pro-rata or otherwise;&nbsp;(c)&nbsp;any
fees you owe to us will immediately become due and payable in full, and
(d)&nbsp;we may delete your archived data within 30 days. All sections of the
Terms that expressly provide for survival, or by their nature should survive,
will survive termination of the Terms, including, without limitation,
indemnification, warranty disclaimers, and limitations of liability.</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h3><a name="_Toc39000039"></a><a name="_Toc38197675"></a><a name="_Toc37430081"></a><a name="_Toc35446801"></a><a name="_Toc32691005"></a><a name="_Toc29655185"></a><a name="_Toc29654653"></a><a name="_Toc28270235"></a><a name="_Toc26650212"></a><a name="_Toc25043005"></a><a name="_Toc24776212"></a><a name="_Toc22984347"></a><a name="_Toc21183324"></a><a name="_Toc21164898"></a><a name="_Toc19817778"></a><a name="_Toc18962819"></a><a name="_Toc18825020"></a><a name="_Toc18674400"></a><a name="_Toc18621751"></a><a name="_Toc18570256"></a><a name="_Toc12078661"><b><span style="font-size:16.0pt;mso-bidi-font-size:14.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">ENTIRE AGREEMENT</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#1F4D78"><o:p></o:p></span></b></h3><p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;mso-line-height-alt:13.5pt"><a name="_Toc12078662"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">This Agreement constitutes the
entire agreement between the parties hereto concerning the subject matter
contained in this Agreement.<o:p></o:p></span></a></p><p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;line-height:13.5pt"><span style="font-size:12.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black"><o:p>&nbsp;</o:p></span></p><p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;mso-line-height-alt:13.5pt"><b><span style="font-size:16.0pt;mso-bidi-font-size:
14.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black">GOVERNING
LAW AND JUDICIAL RECOURSE</span></b><a name="_Toc12078663"></a><b><span style="font-size:16.0pt;mso-bidi-font-size:14.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black"><o:p></o:p></span></b></p><p class="MsoNormal" style="margin-bottom: 11.25pt; text-align: justify; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-fareast-font-family:&quot;Times New Roman&quot;;
mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:black;
mso-themecolor:text1">The terms herein will be governed by and construed under
the Canadian Laws without giving effect to any principles of conflicts of law.
The Courts of Canada shall have exclusive jurisdiction over any dispute arising
from the use of the Website.<o:p></o:p></span></p><h3 style="line-height:12.85pt"><span style="mso-bidi-font-size:11.0pt;
font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-theme-font:minor-latin;color:black;mso-bidi-font-weight:
bold">&nbsp;</span><a name="_Toc39000040"></a><a name="_Toc38197676"></a><a name="_Toc37430082"></a><a name="_Toc35446802"></a><a name="_Toc32691006"></a><a name="_Toc29655186"></a><a name="_Toc29654654"></a><a name="_Toc28270236"></a><a name="_Toc26650213"></a><a name="_Toc25043006"></a><a name="_Toc24776213"></a><a name="_Toc22984348"></a><a name="_Toc21183325"></a><a name="_Toc21164899"></a><a name="_Toc19817779"></a><a name="_Toc18962820"></a><a name="_Toc18825021"></a><a name="_Toc18674401"></a><a name="_Toc18621752"></a><a name="_Toc18570257"><b><span style="font-size:16.0pt;mso-bidi-font-size:14.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">FORCE MAJEURE</span></b></a><b><span style="font-size:16.0pt;mso-bidi-font-size:
14.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:minor-latin;
mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;color:black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span style="font-size:
14.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:minor-latin;
color:#1F4D78"><o:p></o:p></span></b></h3><p class="MsoNormal" style="margin-bottom:11.25pt;text-align:justify;mso-line-height-alt:
13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">We will have no liability
to you, your users, or any third party for any failure us to perform its
obligations under these Terms if such non-performance arises as a result of the
occurrence of an event beyond the reasonable control of us, including, without
limitation, an act of war or terrorism, natural disaster, failure of
electricity supply, riot, civil disorder, or civil commotion or other force
majeure event.</span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;
mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;color:#222222"><o:p></o:p></span></p><h3><a name="_Toc39000041"></a><a name="_Toc38197678"></a><a name="_Toc37430084"></a><a name="_Toc35446804"></a><a name="_Toc32691008"></a><a name="_Toc29655188"></a><a name="_Toc29654656"></a><a name="_Toc28270238"></a><a name="_Toc26650215"></a><a name="_Toc25043008"></a><a name="_Toc24776215"></a><a name="_Toc22984350"></a><a name="_Toc21183327"></a><a name="_Toc21164901"></a><a name="_Toc19817781"></a><a name="_Toc18962822"></a><a name="_Toc18825023"></a><a name="_Toc18674403"></a><a name="_Toc18621754"></a><a name="_Toc18570259"></a><a name="_Toc12078665"><b><span style="font-size:16.0pt;mso-bidi-font-size:14.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">ASSIGNMENT</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#1F4D78"><o:p></o:p></span></b></h3><p class="MsoNormal" style="margin-bottom:11.25pt;text-align:justify;mso-line-height-alt:
13.5pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;color:black">The Company shall have the
right to assign/transfer this agreement to any third party including its
holding company, subsidiaries, affiliates, associates, and group companies,
without any consent of the User.</span><span style="font-size:14.0pt;
mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;color:#222222"><o:p></o:p></span></p><h3><a name="_Toc39000042"></a><a name="_Toc38197679"></a><a name="_Toc37430085"></a><a name="_Toc35446805"></a><a name="_Toc32691009"></a><a name="_Toc29655189"></a><a name="_Toc29654657"></a><a name="_Toc28270239"></a><a name="_Toc26650216"></a><a name="_Toc25043009"></a><a name="_Toc24776216"></a><a name="_Toc22984351"></a><a name="_Toc21183328"></a><a name="_Toc21164902"></a><a name="_Toc19817782"></a><a name="_Toc18962823"></a><a name="_Toc18825024"></a><a name="_Toc18674404"></a><a name="_Toc18621755"></a><a name="_Toc18570260"></a><a name="_Toc12078666"><b><span style="font-size:16.0pt;mso-bidi-font-size:14.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:black">CONTACT INFORMATION</span></b></a><b><span style="font-size:14.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Calibri&quot;,sans-serif;
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
minor-latin;color:#1F4D78"><o:p></o:p></span></b></h3><p>



<w:sdt sdtdocpart="t" docparttype="Table of Contents" docpartunique="t" id="-1180511113">
 
</w:sdt>

</p><p class="MsoNormal" style="text-align:justify;mso-line-height-alt:11.75pt"><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">If you have any questions about
these Terms, please contact us at&nbsp;</span><a href="mailto:contact@talkmaze.com" target="_blank"><span style="font-size: 14pt; color: black;">contact@talkmaze.com</span></a><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;color:black">.</span><span style="font-size: 10.5pt; font-family: Helvetica; color: black; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"> </span><span style="font-size:14.0pt;mso-bidi-font-size:11.0pt;
mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin"><o:p></o:p></span></p>