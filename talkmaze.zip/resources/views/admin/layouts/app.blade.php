<!DOCTYPE html>
<html lang="en">
<head>
    @include("admin.includes.header")
</head>
<body>
@yield('content')
</body>
</html>

