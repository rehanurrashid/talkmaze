<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CourseRating extends Model
{
    protected $guarded =[];
}
