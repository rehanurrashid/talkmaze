<?php

namespace App\Http\Controllers;

use App\TutorRating;
use Illuminate\Http\Request;

class TutorRatingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TutorRating  $tutorRating
     * @return \Illuminate\Http\Response
     */
    public function show(TutorRating $tutorRating)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TutorRating  $tutorRating
     * @return \Illuminate\Http\Response
     */
    public function edit(TutorRating $tutorRating)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TutorRating  $tutorRating
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TutorRating $tutorRating)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TutorRating  $tutorRating
     * @return \Illuminate\Http\Response
     */
    public function destroy(TutorRating $tutorRating)
    {
        //
    }
}
