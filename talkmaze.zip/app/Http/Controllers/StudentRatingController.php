<?php

namespace App\Http\Controllers;

use App\StudentRating;
use Illuminate\Http\Request;

class StudentRatingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\StudentRating  $studentRating
     * @return \Illuminate\Http\Response
     */
    public function show(StudentRating $studentRating)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\StudentRating  $studentRating
     * @return \Illuminate\Http\Response
     */
    public function edit(StudentRating $studentRating)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\StudentRating  $studentRating
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, StudentRating $studentRating)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StudentRating  $studentRating
     * @return \Illuminate\Http\Response
     */
    public function destroy(StudentRating $studentRating)
    {
        //
    }
}
