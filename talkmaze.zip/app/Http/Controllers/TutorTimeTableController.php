<?php

namespace App\Http\Controllers;

use App\TutorTimeTable;
use Illuminate\Http\Request;

class TutorTimeTableController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TutorTimeTable  $tutorTimeTable
     * @return \Illuminate\Http\Response
     */
    public function show(TutorTimeTable $tutorTimeTable)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TutorTimeTable  $tutorTimeTable
     * @return \Illuminate\Http\Response
     */
    public function edit(TutorTimeTable $tutorTimeTable)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TutorTimeTable  $tutorTimeTable
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TutorTimeTable $tutorTimeTable)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TutorTimeTable  $tutorTimeTable
     * @return \Illuminate\Http\Response
     */
    public function destroy(TutorTimeTable $tutorTimeTable)
    {
        //
    }
}
